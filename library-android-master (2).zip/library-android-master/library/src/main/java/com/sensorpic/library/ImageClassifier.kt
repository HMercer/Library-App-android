package com.sensorpic.library

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.Image
import android.media.ThumbnailUtils
import android.os.SystemClock
import com.sensorpic.library.internal.IMAGE_PIXELS
import com.sensorpic.library.internal.ImageProcessor
import com.sensorpic.library.internal.OBJECT_NAME_TO_IGNORE
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.GpuDelegate
import timber.log.Timber
import java.io.BufferedReader
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.util.*

/**
 * Classifies images with TensorFlow Lite using a machine learning model
 */
class ImageClassifier(private val context: Context, private val callback: DetectionListener) {

    /* Pre-allocated buffers for storing image data in. */
    private val intValues = IntArray(DIM_IMG_SIZE_X * DIM_IMG_SIZE_Y)
    /**
     * An instance of the driver class to run model inference with Tensorflow Lite.
     */
    private var tflite: Interpreter
    /**
     * Labels corresponding to the output of the vision model.
     */
    private val labelList: List<String>
    /**
     * A ByteBuffer to hold image data, to be feed into Tensorflow Lite as inputs.
     */
    private var imgData: ByteBuffer
    /**
     * An array to hold inference results, to be feed into Tensorflow Lite as outputs.
     */
    private var labelProbArray: Array<FloatArray>? = null
    /**
     * multi-stage low pass filter
     */
    private var filterLabelProbArray: Array<FloatArray>? = null
    private val sortedLabels = PriorityQueue(
            RESULTS_TO_SHOW,
            Comparator { o1: Map.Entry<String?, Float>, o2: Map.Entry<String?, Float> -> o1.value.compareTo(o2.value) })

    private var topCalculation: Recognition? = null
    private var lastRecognition: Long? = null
    private val frameDurations = mutableListOf<Long>()
    private var imagesBeingProcessed = 0
    private var imageProcessor: ImageProcessor? = null
    private var latestBitmap: Bitmap? = null

    // private lateinit var intValues: IntArray
    // outputLocations: array of shape [Batchsize, NUM_DETECTIONS,4]
    // contains the location of detected boxes
//    private lateinit var outputLocations: Array<Array<FloatArray>>
    // outputClasses: array of shape [Batchsize, NUM_DETECTIONS]
    // contains the classes of detected boxes
//    private lateinit var outputClasses: Array<FloatArray>
    // outputScores: array of shape [Batchsize, NUM_DETECTIONS]
    // contains the scores of detected boxes
//    private lateinit var outputScores: Array<FloatArray>
    // numDetections: array of shape [Batchsize]
    // contains the number of detected boxes
//    private lateinit var numDetections: FloatArray

//    private val NUM_DETECTIONS = 10

    /**
     * Initializes an `ImageClassifier`.
     */
    init {
        val buffer = loadModelFile(context)
        val options = Interpreter.Options()
        options.addDelegate(GpuDelegate())
        options.setNumThreads(4) // For CPU only (not GPU)
        tflite = Interpreter(buffer, options)
        labelList = loadLabelList(context)
        imgData = ByteBuffer.allocateDirect(4 * DIM_BATCH_SIZE * DIM_IMG_SIZE_X * DIM_IMG_SIZE_Y * DIM_PIXEL_SIZE)
        imgData.order(ByteOrder.nativeOrder())
        labelProbArray = Array(1) { FloatArray(labelList.size) }
        filterLabelProbArray = Array(FILTER_STAGES) { FloatArray(labelList.size) }
        Timber.d("Created a Tensorflow Lite Image Classifier.")
    }

    /**
     * Classifies a frame from the preview stream.
     */
//    fun classifyFrame(buffer: ByteBuffer?): String {
//        imgData = buffer!!
//        val startTime = SystemClock.uptimeMillis()
//        tflite.run(imgData, labelProbArray!!)
//        val endTime = SystemClock.uptimeMillis()
        // Timber.d("Timecost to run model inference: " + Long.toString(endTime - startTime));
        // smooth the results
//        applyFilter()
        // print the results
//           }

    fun classifyBitmap(bitmap: Bitmap) {
        val thumbBitmap = ThumbnailUtils.extractThumbnail(bitmap, IMAGE_PIXELS, IMAGE_PIXELS)
        bitmap.recycle()
        classifyBitmapThumb(thumbBitmap)
//        thumbBitmap.recycle()
    }

    fun processFrameImageIfNotAlreadyProcessing(image: Image) {
        if (imagesBeingProcessed == 0) {
            Timber.i("Frame received, starting conversion and processing")
            imagesBeingProcessed++
            processFrameImage(image)
        } else {
//                    Timber.i("Frame received but ignored as processing one already")
            image.close()
        }
    }

    private fun processFrameImage(image: Image) {
        GlobalScope.launch(Dispatchers.IO) {

            if (latestBitmap == null) {
                createNewBitmap(image.width, image.height)
                imageProcessor = ImageProcessor(context, latestBitmap!!)
            }

            // Get the YUV data
            val startGetImageBytesMs = System.currentTimeMillis()
            val yuvBufferOriginal = imageProcessor?.yuvImageToByteBuffer(image)
            //                        val yuvArray = imageConverterRenderScript?.yuvImageToByteArrayX(image)!!
            //                        val yuvBufferOriginal = ImageByteLoader.YUV_420_888toNV21(image)
            val yuvArray = yuvBufferOriginal!!.array()
            val durationGetImageBytes = System.currentTimeMillis() - startGetImageBytesMs

            // Simple scale of YUV image bytes down to one quarter the size
            val startSimpleScaleMs = System.currentTimeMillis()
            val quarterImageBytes = imageProcessor?.halveYUV420(yuvArray, image.width, image.height)
            val yuvBytes = ByteBuffer.wrap(quarterImageBytes ?: ByteArray(0))
            //                        val yuvBytes = ByteBuffer.wrap(yuvBufferOriginal)
            val durationSimpleScale = System.currentTimeMillis() - startSimpleScaleMs

            // From YUV to Bitmap
            val startConversionMs = System.currentTimeMillis()
            val bitmap = imageProcessor?.convertYUV420888ImageToBitmap(yuvBytes)
            val durationConversion = System.currentTimeMillis() - startConversionMs

            if (bitmap != null) {

                // Get quarter sized image
                val startScaleMs = System.currentTimeMillis()
                val scaledBitmap = imageProcessor?.scaleBitmap(bitmap)
                val durationScale1 = System.currentTimeMillis() - startScaleMs

                // Blur
                val startBlurMs = System.currentTimeMillis()
                imageProcessor?.blurBitmap(scaledBitmap)
                val durationBlur = System.currentTimeMillis() - startBlurMs

                // Create cropped, square thumb
                val startThumbScaleMs = System.currentTimeMillis()
                // val originalThumb = ThumbnailUtils.extractThumbnail(scaledBitmap, IMAGE_PIXELS, IMAGE_PIXELS)
                val originalThumb = imageProcessor?.createThumbnail(scaledBitmap)
                // bitmap.recycle()
                val durationThumbScale = System.currentTimeMillis() - startThumbScaleMs

                // Rotate
                // TODO Add sensor orientation
                val startRotateMs = System.currentTimeMillis()
                val matrix = Matrix()
                matrix.setRotate(90f)
                val rotatedThumb = Bitmap.createBitmap(originalThumb!!, 0, 0, originalThumb.width, originalThumb.height, matrix, false)
                originalThumb.recycle()
                val durationRotate = System.currentTimeMillis() - startRotateMs

                //                            ImageSaver.saveToGallery(requireActivity(), rotatedThumb, Bitmap.CompressFormat.PNG, "image/png", "Image ${System.currentTimeMillis()}")

                withContext(Dispatchers.Main) {
                    // TODO Return this to the caller to be displayed
//                    binding.thumb.setImageBitmap(rotatedThumb)
                }

                val startClassificationMs = SystemClock.uptimeMillis()
                classifyBitmapThumb(rotatedThumb)
                // rotatedThumb.recycle()
                val durationClassification = SystemClock.uptimeMillis() - startClassificationMs

                val durationTotal = if (lastRecognition == null) null else (System.currentTimeMillis() - (lastRecognition!!))
                lastRecognition = System.currentTimeMillis()

                durationTotal?.let { frameDurations.add(durationTotal) }
                val averageFrameRate = 1000 / frameDurations.average()

                Timber.d("Durations: TOTAL=${durationTotal ?: "--"}ms (${"%.1f".format(averageFrameRate)}fps). LoadYUVBytes=${durationGetImageBytes}, ScaleToOneQuarter=${durationSimpleScale}ms, ConvertYUVToRGB=${durationConversion}ms, SmoothScale=${durationScale1}ms, Blur=${durationBlur}ms, ThumbScale=${durationThumbScale}ms, Rotate=${durationRotate}ms, Classification:${durationClassification}ms")

            } else {
                Timber.e("Null bitmap received so ignoring")
            }

            withContext(Dispatchers.Main) {
                imagesBeingProcessed--
                image.close()
            }

        }
    }

    private fun createNewBitmap(width: Int, height: Int) {
        if (latestBitmap != null) latestBitmap?.recycle()
        latestBitmap = Bitmap.createBitmap(width / 2, height / 2, Bitmap.Config.ARGB_8888)
    }

    /**
     * Classifies a bitmap thumb from the preview stream.
     */
    private fun classifyBitmapThumb(bitmap: Bitmap) {
        convertBitmapToByteBuffer(bitmap)
        tflite.run(imgData, labelProbArray!!)
        // smooth the results
        applyFilter()
        // print the results
        val textToShow = printTopKLabels()
//        textToShow = (endTime - startTime).toString() + "ms" + textToShow

        // Switch to UI thread
        GlobalScope.launch(Dispatchers.Main) {
            if (topCalculation?.title == OBJECT_NAME_TO_IGNORE) {
                callback.onObjectNotDetected()
                Timber.i("No object detected")
            } else {
                Timber.i("Object MET criteria: ${topCalculation?.title} ${((topCalculation?.confidence ?: 0f) * 100).toInt()}")
                callback.onObjectDetected(topCalculation, true)
            }
        }

//        outputLocations = Array(1) { Array(NUM_DETECTIONS) { FloatArray(4) } }
//        outputClasses = Array(1) { FloatArray(NUM_DETECTIONS) }
//        outputScores = Array(1) { FloatArray(NUM_DETECTIONS) }
//        numDetections = FloatArray(1)
//        val inputArray = arrayOf(imgData)
//        val outputMap: MutableMap<Int, Any> = HashMap()
//        outputMap[0] = outputLocations
//        outputMap[1] = outputClasses
//        outputMap[2] = outputScores
//        outputMap[3] = numDetections




//         TODO Resurrect for multi-object classification and rectangle locations
//        val inputs = arrayOf(imgData, labelProbArray!!)
//        val outputs: MutableMap<Int?, Any?> = mutableMapOf()
//        outputs[0] = labelProbArray
//        Timber.e("XXX 1: About to run multiple inputs outputs")
//        tflite.runForMultipleInputsOutputs(inputArray, outputMap)
//        Timber.e("XXX 2: After running multiple inputs outputs")

//        val recognitions = ArrayList<Recognition?>(NUM_DETECTIONS)
//        for (i in 0 until NUM_DETECTIONS) {
//            val detection = RectF(
//                    outputLocations[0][i][1] * IMAGE_PIXELS,
//                    outputLocations[0][i][0] * IMAGE_PIXELS,
//                    outputLocations[0][i][3] * IMAGE_PIXELS,
//                    outputLocations[0][i][2] * IMAGE_PIXELS)
//            // SSD Mobilenet V1 Model assumes class 0 is background class
//            // in label file and class labels start from 1 to number_of_classes+1,
//            // while outputClasses correspond to class index from 0 to number_of_classes
//            val labelOffset = 1
//            recognitions.add(
//                    Recognition(
//                            "" + i,
//                            labelList[outputClasses[0][i].toInt() + labelOffset],
//                            outputScores[0][i],
//                            detection))
//        }
//        Timber.e("XXX 3: $recognitions")
    }

    private fun applyFilter() {
        val labelCount = labelList.size
        // Low pass filter `labelProbArray` into the first stage of the filter.
        for (j in 0 until labelCount) {
            filterLabelProbArray!![0][j] += FILTER_FACTOR * (labelProbArray!![0][j] -
                    filterLabelProbArray!![0][j])
        }
        // Low pass filter each stage into the next.
        for (i in 1 until FILTER_STAGES) {
            for (j in 0 until labelCount) {
                filterLabelProbArray!![i][j] += FILTER_FACTOR * (filterLabelProbArray!![i - 1][j] -
                        filterLabelProbArray!![i][j])
            }
        }
        // Copy the last stage filter output back to `labelProbArray`.
        for (j in 0 until labelCount) {
            labelProbArray!![0][j] = filterLabelProbArray!![FILTER_STAGES - 1][j]
        }
    }

    /**
     * Closes tflite to release resources.
     */
    fun close() {
        tflite.close()
    }

    /**
     * Reads label list from Assets.
     */
    @Throws(IOException::class)
    private fun loadLabelList(context: Context): List<String> {
        val labelList: MutableList<String> = ArrayList()
        val reader = BufferedReader(InputStreamReader(context.assets.open(LABEL_PATH)))
        var line: String?
        while (reader.readLine().also { line = it } != null) {
            val l = line
            if (l != null) labelList.add(l)
        }
        reader.close()
        return labelList
    }

    /**
     * Memory-map the model file in Assets.
     */
    @Throws(IOException::class)
    private fun loadModelFile(activity: Context): ByteBuffer {
        val fileDescriptor = activity.assets.openFd(MODEL_PATH)
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        val startOffset = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength).asReadOnlyBuffer()
    }

    /**
     * Writes Image data into a `ByteBuffer`.
     */
    private fun convertBitmapToByteBuffer(bitmap: Bitmap) {
        imgData.rewind()
        bitmap.getPixels(intValues, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        // Convert the image to floating point.
        var pixel = 0
//        val startTime = SystemClock.uptimeMillis()
        for (i in 0 until DIM_IMG_SIZE_X) {
            for (j in 0 until DIM_IMG_SIZE_Y) {
                val `val` = intValues[pixel++]
                imgData.putFloat(((`val` shr 16 and 0xFF) - IMAGE_MEAN) / IMAGE_STD)
                imgData.putFloat(((`val` shr 8 and 0xFF) - IMAGE_MEAN) / IMAGE_STD)
                imgData.putFloat(((`val` and 0xFF) - IMAGE_MEAN) / IMAGE_STD)
            }
        }
//        val endTime = SystemClock.uptimeMillis()
        //        Timber.d("Timecost to put values into ByteBuffer: " + Long.toString(endTime - startTime));
    }

    /**
     * Prints top-K labels, to be shown in UI as the results.
     */
    private fun printTopKLabels(): String {
        for (i in labelList.indices) {
            sortedLabels.add(AbstractMap.SimpleEntry(labelList[i], labelProbArray!![0][i]))
            if (sortedLabels.size > RESULTS_TO_SHOW) {
                sortedLabels.poll()
            }
        }
        var textToShow = ""
        val size = sortedLabels.size
        for (i in 0 until size) {
            val label = sortedLabels.poll()
            //            Timber.d("label " + label.getKey() + " value " + label.getValue());
            if (i == size - 1) {
                topCalculation = Recognition(title = label?.key, confidence = label?.value)
            }
            textToShow = String.format("\n%s: %4.2f", label?.key, label?.value) + textToShow
        }
        return textToShow
    }

    companion object {
        /**
         * Name of the model file stored in Assets.
         */
        private const val MODEL_PATH = "detect.tflite"
        /**
         * Name of the label file stored in Assets.
         */
        private const val LABEL_PATH = "labelmap.txt"
        /**
         * Number of results to show in the UI.
         */
        private const val RESULTS_TO_SHOW = 3
        /**
         * Dimensions of inputs.
         */
        private const val DIM_BATCH_SIZE = 1
        private const val DIM_PIXEL_SIZE = 3
        val DIM_IMG_SIZE_X = IMAGE_PIXELS
        val DIM_IMG_SIZE_Y = IMAGE_PIXELS
        private const val IMAGE_MEAN = 128
        private const val IMAGE_STD = 128.0f
        private const val FILTER_STAGES = 3
        private const val FILTER_FACTOR = 0.4f
    }

}
