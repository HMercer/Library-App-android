package com.sensorpic.library.internal

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageFormat
import android.graphics.RectF
import android.media.Image
import android.media.ThumbnailUtils
import android.renderscript.*
import java.nio.ByteBuffer

/**
 * Utility methods to take a YUV_420_888 Image object and process it:
 * - Convert it to a YUV ByteBuffer
 * - Rapidly scale it to a quarter size (halved width and height) for faster handling
 * - Convert the smaller YUV image data into an RGB Android Bitmap
 *
 */
internal class ImageProcessor(context: Context?, private var bitmap: Bitmap) {

    private var bytesOutput: ByteBuffer = ByteBuffer.allocate(0)
    private val rs = RenderScript.create(context)

    fun yuvImageToByteBuffer(image: Image): ByteBuffer {
        val crop = image.cropRect
        val width = crop.width()
        val height = crop.height()
        val planes = image.planes
        val rowData = ByteArray(planes[0].rowStride)
        val bufferSize = width * height * ImageFormat.getBitsPerPixel(ImageFormat.YUV_420_888) / 8

        if (bytesOutput.array().size != bufferSize) {
            bytesOutput = ByteBuffer.allocateDirect(bufferSize)
        }

        var channelOffset = 0
        var outputStride = 0
        for (planeIndex in 0..2) {
            when (planeIndex) {
                0 -> {
                    channelOffset = 0
                    outputStride = 1
                }
                1 -> {
                    channelOffset = width * height + 1
                    outputStride = 2
                }
                2 -> {
                    channelOffset = width * height
                    outputStride = 2
                }
                //            Timber.e("Plane ${planeIndex}: ${System.currentTimeMillis() - startPlaneMs}ms")
            }
            val buffer = planes[planeIndex].buffer
            val rowStride = planes[planeIndex].rowStride
            val pixelStride = planes[planeIndex].pixelStride
            val shift = if (planeIndex == 0) 0 else 1
            val widthShifted = width shr shift
            val heightShifted = height shr shift
            buffer.position(rowStride * (crop.top shr shift) + pixelStride * (crop.left shr shift))
            for (row in 0 until heightShifted) {
                val length: Int
                if (pixelStride == 1 && outputStride == 1) {
                    length = widthShifted
                    buffer[bytesOutput.array(), channelOffset, length]
                    channelOffset += length
                } else {
                    length = (widthShifted - 1) * pixelStride + 1
                    buffer[rowData, 0, length]
                    for (col in 0 until widthShifted) {
                        bytesOutput.array()[channelOffset] = rowData[col * pixelStride]
                        channelOffset += outputStride
                    }
                }
                if (row < heightShifted - 1) {
                    buffer.position(buffer.position() + rowStride - length)
                }
            }
        }
        return bytesOutput
    }

    fun halveYUV420(data: ByteArray, imageWidth: Int, imageHeight: Int): ByteArray? {
        val yuv = ByteArray(imageWidth / 2 * imageHeight / 2 * 3 / 2)
        // halve yuma
        var i = 0
        run {
            var y = 0
            while (y < imageHeight) {
                var x = 0
                while (x < imageWidth) {
                    yuv[i] = data[y * imageWidth + x]
                    i++
                    x += 2
                }
                y += 2
            }
        }
        // halve U and V color components
        var y = 0
        while (y < imageHeight / 2) {
            var x = 0
            while (x < imageWidth) {
                yuv[i] = data[imageWidth * imageHeight + y * imageWidth + x]
                i++
                yuv[i] = data[imageWidth * imageHeight + y * imageWidth + (x + 1)]
                i++
                x += 4
            }
            y += 2
        }
        return yuv
    }

    fun convertYUV420888ImageToBitmap(yuvBytes: ByteBuffer): Bitmap {

        // Copy YUV image bytes into allocation
        val allocationYuv: Allocation = Allocation.createSized(rs, Element.U8(rs), yuvBytes.array().size)
        allocationYuv.copyFrom(yuvBytes.array())


        // Convert YUV to RGB
        val allocationRGB: Allocation = Allocation.createFromBitmap(rs, bitmap)
        val scriptYuvToRgb = ScriptIntrinsicYuvToRGB.create(rs, Element.U8_4(rs))
        scriptYuvToRgb.setInput(allocationYuv)
        scriptYuvToRgb.forEach(allocationRGB)

        // Write RGB bytes to Bitmap
        allocationRGB.copyTo(bitmap)

        // Release
        allocationYuv.destroy()
        allocationRGB.destroy()
        rs?.destroy()
        return bitmap
    }

    fun scaleBitmap(bitmap: Bitmap) : Bitmap {
        return Bitmap.createScaledBitmap(bitmap, bitmap.width / 2, bitmap.height / 2, true)
    }

    fun blurBitmap(scaled1: Bitmap?) {
        val input = Allocation.createFromBitmap(rs, scaled1) //use this constructor for best performance, because it uses USAGE_SHARED mode which reuses memory
        val output = Allocation.createTyped(rs, input.type)
        val script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs))
        script.setRadius(4f)
        script.setInput(input)
        script.forEach(output)
        output.copyTo(scaled1)
    }

    fun createThumbnail(scaledBitmap: Bitmap?) : Bitmap {
        return ThumbnailUtils.extractThumbnail(scaledBitmap, IMAGE_PIXELS, IMAGE_PIXELS)
    }

//    private fun scaleRectangle(rectangle: RectF?): RectF? {
//        if (rectangle == null) return null
//        val widthExtra = scaled.width() * 0.125f
//        val heightExtra = scaled.height() * 0.125f
//        return RectF(scaled.left - widthExtra, scaled.top - heightExtra, scaled.right + widthExtra, scaled.bottom + heightExtra )
//        val horizontalScale = (1.0f / IMAGE_PIXELS) * width
//        val verticalScale = (1.0f / IMAGE_PIXELS) * height
//        val scaled = if (imageIsPortrait) {
//            RectF(rectangle.left * horizontalScale, rectangle.top * verticalScale, rectangle.right * horizontalScale, rectangle.bottom * verticalScale)
//        } else {
//            RectF(rectangle.top * horizontalScale, rectangle.right * verticalScale, rectangle.bottom * horizontalScale, rectangle.left * verticalScale)
//        }
//        return scaled
//    }

    private fun createInitialRectangle(): RectF {
        return RectF(0f, 0f, 0f, 0f)
    }

}
