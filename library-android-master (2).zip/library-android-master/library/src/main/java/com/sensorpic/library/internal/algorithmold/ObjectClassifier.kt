package com.sensorpic.library.internal.algorithmold

import android.content.Context
import android.graphics.Bitmap
import android.widget.Toast
import com.sensorpic.library.internal.IMAGE_PIXELS
import com.sensorpic.library.DetectionListener
import timber.log.Timber
import java.io.IOException

/**
 * Created by Junaid Ali on 02,December,2019
 */
internal class ObjectClassifier(context: Context, private val carDetectionListener: DetectionListener) {

    private val OBJECT_NAME_TO_DETECT = "car"
    private lateinit var detector: Classifier

    init {
        try {
            detector = ImageClassifierOld.create(
                    context.assets,
                    TF_OD_API_MODEL_FILE,
                    TF_OD_API_LABELS_FILE,
                    TF_OD_API_INPUT_SIZE,
                    TF_OD_API_IS_QUANTIZED)
        } catch (e: IOException) {
            e.printStackTrace()
            Timber.e("Exception initializing classifier")
            Toast.makeText(context, "Failed to initialize the classifier", Toast.LENGTH_LONG).show()
        }
    }

    fun detectCar(croppedBitmap: Bitmap, isPortrait: Boolean) {
        Timber.e("XXX detectCar()")
        val results = detector.recognizeImage(croppedBitmap)?.filterNotNull() ?: listOf()
        Timber.e("XXX 1 $results")
        val objects = results.filter { it.title == OBJECT_NAME_TO_DETECT }
        Timber.e("XXX 2 $objects")
        val objectsConfident = objects.filter { (it.confidence ?: 0.0f).toDouble() >= 0.7 }
        Timber.e("XXX 3 $objectsConfident")
        val areas = objectsConfident.sortedByDescending { it.getArea() }
        Timber.e("XXX 4 Results: $areas");
        if (areas.isNotEmpty()) {
            val recognition = areas[0]
            carDetectionListener.onObjectDetected(recognition, isPortrait)
        } else {
            carDetectionListener.onObjectNotDetected()
        }
    }

    companion object {
        // Configuration values for the prepackaged SSD model.
        private val TF_OD_API_INPUT_SIZE = IMAGE_PIXELS
        private const val TF_OD_API_IS_QUANTIZED = true
        private const val TF_OD_API_MODEL_FILE = "detect.tflite"
        private const val TF_OD_API_LABELS_FILE = "file:///android_asset/labelmap.txt"
    }

}