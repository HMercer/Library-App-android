package com.sensorpic.library

interface DetectionListener {

    fun onObjectDetected(recognition: Recognition?, isPortrait: Boolean)
    fun onObjectNotDetected()

}
