package com.sensorpic.library

import android.graphics.RectF

/** An immutable result returned by a Classifier describing what was recognized.  */
data class Recognition(
        /**
         * A unique identifier for what has been recognized. Specific to the class, not the instance of
         * the object.
         */
        val id: String? = null,

        /** Display name for the recognition.  */
        val title: String?,
        /**
         * A sortable score for how good the recognition is relative to others. Higher should be better.
         */
        val confidence: Float?,

        /** Optional location within the source image for the location of the recognized object.  */
        var location: RectF? = null) {

    fun getArea() : Float {
        val width = location?.width() ?: 0.0f
        val height = location?.height() ?: 0.0f
        return width * height
    }

}
