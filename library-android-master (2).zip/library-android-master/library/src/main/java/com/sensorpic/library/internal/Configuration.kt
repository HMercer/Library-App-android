package com.sensorpic.library.internal

/**
 * Core configuration settings
 */
internal const val OBJECT_NAME_TO_IGNORE = "non_nude"
internal const val IMAGE_PIXELS = 224
