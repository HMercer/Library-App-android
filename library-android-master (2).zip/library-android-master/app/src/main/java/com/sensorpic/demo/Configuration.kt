package com.sensorpic.demo

const val DEFAULT_ML_CONFIDENCE_THRESHOLD = 0.7f
